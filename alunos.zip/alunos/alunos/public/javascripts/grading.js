function reset() {
    gForm.reset();
}


function calculate() {
    output.innerHTML = sName.value;
}


let sName;
let uName;
let projectG;
let projectP;
let testG;
let testP;
let output;
let gForm;


window.onload = () => {

    sName = document.getElementById("sname");
    uName = document.getElementById("uname");
    projectG = document.getElementById("projectg");
    projectP = document.getElementById("projetcp");
    testG = document.getElementById("testeg");
    testP = document.getElementById("testp");
    output = document.getElementById("output")
    gForm = document.getElementById('gForm')

}