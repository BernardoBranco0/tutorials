
var nameStudent = 'John Smith';

window.onload = function(){
    document.getElementById("student").innerHTML = nameStudent += " grades";
}

var studentName; 

const Grades = [
    {
        name: 'Mathematics',
        grade: 7.5,
    },
    
    {
        name: 'Literature',
        grade: 11.2,
    } 
];








window.onload = () => {
    createCards();
};

function createCards() {
    let main = document.getElementById('grades');
    for (let idx in Grades) {
      main.innerHTML += makeCard(idx);
    }  
}

function showGrades(idxGrades) {
    sessionStorage.setItem('greadeGread', idxGrades);
    sessionStorage.setItem('studentName', Grades[idxGrades].name);
    window.location = 'studentGrades.html';
}

function makeCard(idxGrades) {
    return `<div class="grade-card ${Grades[idxGrades].grade < 9.5 ? "failed" : ""}" onclick="showGrades(${idxGrades})">
        <h2>
            ${Grades[idxGrades].name}
        </h2>
        <p>
            ${Grades[idxGrades].grade}
        </p>
    </div>`;
} 

window.onload = () => {
    createCards();
};

