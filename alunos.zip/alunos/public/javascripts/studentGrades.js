
var nameStudent
var nameStudent;
var studentId;
/*var nameStudent;
var studentName;
var studentId;*/
const allGrades = [
    [
        {
            name: 'Mathematics',
            grade: 8.3,
            semester: '3rd Semester',
            ects: 6
        },
        {
            name: 'Literature',
            grade: 11.2,
            semester: '2nd Semester',
            ects: 6
        },
        {
            name: 'Laws',
            grade: 18.5,
            semester: '1st Semester',
            ects: 3
        },
        {
            name: 'Informatics',
            grade: 14.3,
            semester: '1st Semester',
            ects: 6
        },
        {
            name: 'Cooking',
            grade: 7.4,
            semester: '2nd Semester',
            ects: 3
        },
    ],
    [
        {
            name: 'Mathematics',
            grade: 14.5,
            semester: '3rd Semester',
            ects: 6
        },
        {
            name: 'Literature',
            grade: 10.6,
            semester: '2nd Semester',
            ects: 6
        },
        {
            name: 'Laws',
            grade: 8.7,
            semester: '1st Semester',
            ects: 3
        },
    ],
    [
        {
            name: 'Mathematics',
            grade: 12.3,
            semester: '3rd Semester',
            ects: 6
        },
        {
            name: 'Literature',
            grade: 14.8,
            semester: '2nd Semester',
            ects: 6
        },
    ],
];




window.onload = () => {
    nameStudent = sessionStorage.getItem('studentName');
    createCards();
    document.getElementById("student").innerHTML = nameStudent += " grades";
    let exameGrades = getSum();
    let failedGrades = getFailedGrades();
    let finishedGrades = getFinishedGrades();
    showAverage(exameGrades, failedGrades, finishedGrades);
    showFailed(failedGrades);
    showFinished(finishedGrades);
};

function showAverage(exameGrades, failedGrades, finishedGrades) {
    let average = exameGrades / (failedGrades + finishedGrades);
    document.getElementById("summaryText").innerHTML = `Average: ${average}`;
}

function getSum() {
    let sum = 0;
    for (let grade of allGrades[studentId])
        sum += grade.grade;
    return sum;

}

function showFailed(failedGrades) {
    document.getElementById("summary").innerHTML += `<p> Failed Grades: ${failedGrades} </p>`;
}

function getFailedGrades() {
    let failedGrades = 0;
    for (let grade of Grades)
        if (grade.grade < 9.5)
            failedGrades++;
    return failedGrades;
}

function showFinished(finishedGrades) {
    document.getElementById("summary").innerHTML += `<p> Finished Grades: ${finishedGrades} </p>`;
}

function getFinishedGrades() {
    let finishedGrades = 0;
    for (let grade of Grades)
        if (grade.grade >= 9.5)
            finishedGrades++;
    return finishedGrades;
}

function createCards() {
    let main = document.getElementById('grades');
    for (let idx in Grades) {
        main.innerHTML += makeCard(idx);
    }
}

function showGrades(idxGrades) {
    sessionStorage.setItem('gradeGrade', idxGrades);
    sessionStorage.setItem('studentName', Grades[idxGrades].name);
    window.location = 'studentGrades.html';
}

function makeCard(idxGrades) {
    return `<div class="grade-card ${Grades[idxGrades].grade < 9.5 ? "failed" : ""}" onclick="showGrades(${idxGrades})">
        <h2>
            ${Grades[idxGrades].name}
        </h2>
        <p>
            Grade: ${Grades[idxGrades].grade}
        </p>
        <p>
            Semester: ${Grades[idxGrades].semester}
        </p>
        <p>
            ECTS: ${Grades[idxGrades].ects}
        </p>
        
    </div>`;
}


